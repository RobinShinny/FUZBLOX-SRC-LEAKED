<div class="rightnav">
<a style="font-size:27px;font-weight:700;">Admin Panel</a>
<a>Ban Users</a>
<a>Aduit Logs</a>
<a>Approve Items</a>
<a>Site History</a>
<a>Upload Items</a>
<a>Account Generator</a>
<a>Hire Admins!</a>
<a>Moderate Groups</a>
<a>Shutdown</a>
<a>Banner Update</a>
<a>Users Info</a>
<a>Upload Assets</a>
<a>Clear Cache</a>
<a>Clean Site</a>
<a>Database leak</a>
<a>Current Language</a>
<a>Shutdown Site!</a>
</div>
