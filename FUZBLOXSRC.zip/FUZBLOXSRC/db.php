<?php
$servername = "sql305.infinityfree.com";
$username = "if0_37312422";
$password = "XTqzjSUdmQW5Ft";
$db = "if0_37312422_lol";

$conn = mysqli_connect($servername, $username, $password, $db);
?>
<link rel="icon" type="image/png" href="fuzblox.png">