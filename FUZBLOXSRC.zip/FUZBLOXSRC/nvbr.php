<div class="oldnavbar">
<?php 
session_start();

?>


<img  src="banner.png"style="width: 100%;">

<a  style="text-decoration:none; color:black;" href="/default.php">My FuzBlox: A Free To Play Game! |</a>


<a> Catalog |</a>


<a> Group |</a>

<a> BuildersClub! </a>


</div>